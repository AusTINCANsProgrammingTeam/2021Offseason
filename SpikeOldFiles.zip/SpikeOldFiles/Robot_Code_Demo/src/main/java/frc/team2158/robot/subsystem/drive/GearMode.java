package frc.team2158.robot.subsystem.drive;

/**
 * @author William Blount
 * @version 0.0.1
 * Enum listing the Gear Modes
 */
public enum GearMode {HIGH, LOW}
