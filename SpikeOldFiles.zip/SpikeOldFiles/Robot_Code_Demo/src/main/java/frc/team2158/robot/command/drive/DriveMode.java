package frc.team2158.robot.command.drive;

/**
 * Simple enum for both drive configurations.
 */
public enum DriveMode {ARCADE, TANK}
